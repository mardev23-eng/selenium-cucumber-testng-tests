package dev.marvinmarzon.utils;


import org.jcodec.api.awt.AWTSequenceEncoder;
import org.jcodec.common.model.Rational;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class VideoRecorder {

    private static AWTSequenceEncoder encoder;
    private static File lastRecordedFile; // Track last video file
    private static final String BASE_VIDEO_PATH = "target/videos";

    public static void startRecording(String scenarioName) throws IOException, AWTException {
        File videoDir = new File(BASE_VIDEO_PATH);
        if (!videoDir.exists() && !videoDir.mkdirs()) {
            throw new IOException("Failed to create directory for video recording: " + BASE_VIDEO_PATH);
        }

        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String sanitizedScenarioName = scenarioName.replaceAll("[^a-zA-Z0-9_-]", "_");
        String fileName = String.format("%s_%s.mp4", sanitizedScenarioName, timestamp);

        lastRecordedFile = new File(videoDir, fileName);

        // Set the frame rate to 3 FPS (slower video)
        encoder = AWTSequenceEncoder.createSequenceEncoder(lastRecordedFile, 3);  // 3 FPS

        // Start the screen capture process
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Rectangle captureSize = new Rectangle(0, 0, screenSize.width, screenSize.height);

        Robot robot = new Robot();

        // Capture frames and encode them in the encoder
        new Thread(() -> {
            try {
                while (!Thread.currentThread().isInterrupted()) {
                    BufferedImage screenCapture = robot.createScreenCapture(captureSize);
                    encoder.encodeImage(screenCapture);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
    }

    public static void stopRecording() throws IOException {
        if (encoder != null) {
            try {
                encoder.finish();  // Finalize the video file
            } catch (IOException e) {
                throw new IOException("Error finalizing video encoding", e);
            }
        }
    }

    public static String getLastRecordedFilePath() {
        return lastRecordedFile != null ? lastRecordedFile.getAbsolutePath() : null;
    }
}