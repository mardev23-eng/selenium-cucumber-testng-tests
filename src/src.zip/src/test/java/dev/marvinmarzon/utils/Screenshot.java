package dev.marvinmarzon.utils;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;

public class Screenshot {
    private static final String BASE_SCREENSHOT_PATH = "target/images/";

    public static String takeScreenshot(WebDriver driver, String scenarioName) {
        TakesScreenshot ts = (TakesScreenshot) driver;
        File source = ts.getScreenshotAs(OutputType.FILE);
        String filePath = String.format("%s%s.png", BASE_SCREENSHOT_PATH, scenarioName);

        try {
            File destination = new File(filePath);
            FileUtils.copyFile(source, destination);
            System.out.println("Screenshot saved for scenario: " + filePath);
            return filePath; // Return the path to be attached
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
