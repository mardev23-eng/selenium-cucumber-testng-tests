package dev.marvinmarzon.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class TestConfigManager {
    private static final String CONFIG_FILE = "src/test/resources/testConfig.properties";
    private static final Properties properties = new Properties();

    static {
        try (FileInputStream fis = new FileInputStream(CONFIG_FILE)) {
            properties.load(fis);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load testConfig.properties", e);
        }
    }

    private static String getEnvOrProperty(String key, String defaultValue) {
        String envValue = System.getenv(key.toUpperCase().replace('.', '_'));
        if (envValue != null && !envValue.isEmpty()) {
            return envValue;
        }
        return properties.getProperty(key, defaultValue);
    }

    public static String getUrl() {
        return getEnvOrProperty("url", "https://example.com");
    }

    public static String getBrowserStackUsername() {
        return getEnvOrProperty("BROWSERSTACK_USERNAME", "");
    }

    public static String getBrowserStackAccessKey() {
        return getEnvOrProperty("BROWSERSTACK_ACCESS_KEY", "");
    }

    public static String getFilePath() {
        return getEnvOrProperty("file_path", "src/test/resources/data.csv");
    }

    public static String getBrowser() {
        return getEnvOrProperty("browser", "chrome");
    }

    public static boolean isHeadless() {
        return Boolean.parseBoolean(getEnvOrProperty("headless", "false"));
    }

    public static int getWindowWidth() {
        return Integer.parseInt(getEnvOrProperty("window.width", "1280"));
    }

    public static int getWindowHeight() {
        return Integer.parseInt(getEnvOrProperty("window.height", "800"));
    }

    public static boolean isCI() {
        return Boolean.parseBoolean(getEnvOrProperty("ci", "false"));
    }
}
