package dev.marvinmarzon.utils;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;

import java.util.logging.Level;

public class DriverFactory {
    private static WebDriver driver;

    public static WebDriver getDriver() {
        return getDriver(TestConfigManager.getBrowser());
    }

    public static WebDriver getDriver(String browser) {
        if (driver == null) {
            boolean headless = TestConfigManager.isHeadless();
            int width = TestConfigManager.getWindowWidth();
            int height = TestConfigManager.getWindowHeight();

            switch (browser.toLowerCase()) {
                case "firefox":
                    WebDriverManager.firefoxdriver().setup();
                    FirefoxOptions firefoxOptions = new FirefoxOptions();
                    if (headless) {
                        firefoxOptions.addArguments("--headless=new");
                    }
                    firefoxOptions.addArguments("--width=" + width);
                    firefoxOptions.addArguments("--height=" + height);
                    driver = new FirefoxDriver(firefoxOptions);
                    break;

                case "edge":
                    WebDriverManager.edgedriver().setup();
                    EdgeOptions edgeOptions = new EdgeOptions();
                    if (headless) {
                        edgeOptions.addArguments("--headless=new");
                    }
                    edgeOptions.addArguments("--window-size=" + width + "," + height);
                    LoggingPreferences edgeLogPrefs = new LoggingPreferences();
                    edgeLogPrefs.enable(LogType.BROWSER, Level.ALL);
                    edgeOptions.setCapability("ms:loggingPrefs", edgeLogPrefs);
                    driver = new EdgeDriver(edgeOptions);
                    break;

                case "chrome":
                default:
                    WebDriverManager.chromedriver().setup();
                    ChromeOptions chromeOptions = getChromeOptions(headless, width, height);

                    LoggingPreferences chromeLogPrefs = new LoggingPreferences();
                    chromeLogPrefs.enable(LogType.BROWSER, Level.ALL);
                    chromeOptions.setCapability("goog:loggingPrefs", chromeLogPrefs);

                    driver = new ChromeDriver(chromeOptions);
                    break;
            }
        }

        return driver;
    }

    private static ChromeOptions getChromeOptions(boolean headless, int width, int height) {
        ChromeOptions chromeOptions = new ChromeOptions();

        // Common options for both headless and GUI
        chromeOptions.addArguments("--disable-gpu");
        chromeOptions.addArguments("--no-sandbox");
        chromeOptions.addArguments("--disable-dev-shm-usage");

        if (headless) {
            chromeOptions.addArguments("--headless=new");
        }

        chromeOptions.addArguments("--window-size=" + width + "," + height);
        return chromeOptions;
    }

    public static void quitDriver() {
        if (driver != null) {
            driver.quit();
            driver = null;
        }
    }
}
