package dev.marvinmarzon.support;

import dev.marvinmarzon.models.TestConfigData;
import org.openqa.selenium.WebDriver;

public class TestConfigSupport {
    private static TestConfigData testConfigData;

    public static void setTestConfigData(TestConfigData configData) {
        testConfigData = configData;
    }

    public static WebDriver getDriver() {
        if (testConfigData == null) {
            throw new IllegalStateException("TestConfigData has not been initialized.");
        }
        return testConfigData.driver();
    }

    public static String getUrl() {
        if (testConfigData == null) {
            throw new IllegalStateException("TestConfigData has not been initialized.");
        }
        return testConfigData.url();
    }
}

