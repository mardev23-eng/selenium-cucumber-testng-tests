package dev.marvinmarzon;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
        features = {
                "src/test/resources/features/ProfileEndToEnd.feature"
        },
        glue = "org.innodata.stepdefs",
        plugin = {
                "pretty",
                "html: reports/cucumber-html-report.html",
                "io.qameta.allure.cucumber7jvm.AllureCucumber7Jvm"
        }
)


public class TestRunWebDriverCucumber extends AbstractTestNGCucumberTests {
}