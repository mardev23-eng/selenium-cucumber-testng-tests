package dev.marvinmarzon.stepdefs;

import dev.marvinmarzon.models.TestConfigData;
import dev.marvinmarzon.support.TestConfigSupport;
import dev.marvinmarzon.utils.DriverFactory;
import dev.marvinmarzon.utils.TestConfigManager;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import org.openqa.selenium.WebDriver;

public class BaseStep {

    protected WebDriver driver;

    @Before(order = 0)
    public void initDriver() {
        String browser = TestConfigManager.getBrowser();
        driver = DriverFactory.getDriver(browser);
    }

    @Before(order = 1)
    public void openUrlAndSetupConfigData() {
        String url = TestConfigManager.getUrl();
        driver.get(url);

        TestConfigData configData = new TestConfigData(driver, url);
        TestConfigSupport.setTestConfigData(configData);
    }

    @After
    public void tearDown() {
        DriverFactory.quitDriver();
    }
}