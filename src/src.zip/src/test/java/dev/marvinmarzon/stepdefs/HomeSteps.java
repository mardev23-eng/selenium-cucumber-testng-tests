package dev.marvinmarzon.stepdefs;

import dev.marvinmarzon.support.TestConfigSupport;
import io.cucumber.java.en.Given;
import org.openqa.selenium.WebDriver;

public class HomeSteps {
    WebDriver driver;

    public HomeSteps() {
        driver = TestConfigSupport.getDriver();
    }

    @Given("I am in the landing page")
    public void iAmInTheLandingPage() {
        String title = driver.getTitle();
        System.out.println("page title: " + title);
    }
}
