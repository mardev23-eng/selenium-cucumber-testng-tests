package dev.marvinmarzon.models;

import org.openqa.selenium.WebDriver;

public record TestConfigData(WebDriver driver, String url) {
}

